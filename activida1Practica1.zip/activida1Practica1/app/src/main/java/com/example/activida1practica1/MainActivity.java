package com.example.activida1practica1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    Button button1;
    EditText txt1;
    TextView etiqueta;
    Button button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1 = (Button) findViewById(R.id.button1);
        txt1 = (EditText) findViewById(R.id.num);
        etiqueta= (TextView) findViewById(R.id.txt2);
        button2=(Button)findViewById(R.id.button2);

        //Metodo 1
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double valor = Double.parseDouble(txt1.getText().toString());
                double doble = valor*2;
                Toast.makeText(getApplicationContext(),"El doble de "+valor+" es "+doble,Toast.LENGTH_LONG).show();
                etiqueta.setText("El doble es: "+doble);
            }
        });
        //Metodo2
        button2.setOnClickListener(this::onClick);

    }

    public void onClick(View view) {
        double valor = Double.parseDouble(txt1.getText().toString());
        double doble = valor*2;
        Toast.makeText(getApplicationContext(),"El doble de "+valor+" es "+doble,Toast.LENGTH_LONG).show();
        etiqueta.setText("El doble es: "+doble);
    }


}
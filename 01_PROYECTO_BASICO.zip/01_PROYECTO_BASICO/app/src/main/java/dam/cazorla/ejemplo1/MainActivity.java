package dam.cazorla.ejemplo1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/*Todos los activities heredan de la clase Activity, pero por compatibilidad todas heredan de AppCompatActivity
que a su vez hereda de Activity*/
public class MainActivity extends AppCompatActivity {

    //Se definen los componentes a los que voy a referenciar
    TextView etiqueta;
    TextView campoNombre;
    Button boton1;

    @Override //Extendemos el método del padre
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);//Invoca al método onCreate del Padre
        setContentView(R.layout.activity_main);//R es el Repositorio de de Android, y dentro tiene también los layouts
        //El método setContentView lo que hace es abrir el layout que especificamos

        //La función findViewById permite hacer referencia a los elementos de la interfaz gráfica
        //Siempre empieza por R.id....
        //Vamos a usar la  misma notación para no equivocarnos:
        //Tanto para las variables como para los id usamos el típico Lower Camel Case de Java
        //Pero en los id utilizamos el nombre del view
        boton1 = (Button) findViewById(R.id.boton1);
        etiqueta = (TextView) findViewById(R.id.etiquetaNombre);
        campoNombre = (TextView) findViewById(R.id.cajaNombre);

        //Establezco un valor inicial para la etiqueta. También se podría haber hecho desde el SDK
        campoNombre.setText("Introduce tu nombre");


        //Cada evento tiene su función asociada, en este Listener se llama onClick
        campoNombre.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { //El objeto View es el Padre del componente que estamos tratando, en este caso de campo_nombre
                campoNombre.setText("");

            }
        });

        boton1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                etiqueta.setText("Tu nombre es: "+campoNombre.getText());
                /*La función Toast emite mensajes en la parte inferior. El primer parámetro indica en qué contexto lo emite, el segundo el texto
                y el tercero el tiempo que dura*/
                Toast.makeText(getApplicationContext()," El nombre se ha cambiado a "+campoNombre.getText() ,Toast.LENGTH_SHORT).show();
                /*Para escribir en el LOG (ayuda a la depuración) se usa Log.d(tag, message);. El tag es el tipo de mensaje.

    Verbose: se muestran todos los mensajes de registro (configuración predeterminada).
    Debug: se muestran los mensajes de registro de depuración que son útiles durante el desarrollo únicamente, como también los niveles de mensaje más abajo en esta lista.
    Info: se muestran los mensajes de registro esperados para uso regular, como también los niveles de mensaje más abajo en esta lista.
    Warn: se muestran posibles problemas que todavía no se consideran como errores, y los niveles de mensaje, más abajo en esta lista.
    Error: se muestran los problemas que generaron errores, y también el nivel de mensaje, más abajo en esta lista.
    Assert: se muestran problemas que el desarrollador espera que nunca sucedan.

                 */
                Log.d("Verbose","El nombre se ha cambiado a "+campoNombre.getText());
                Log.d("Verbose","Ha pasado por aquí");
            }
        });

        Button boton2 = (Button) findViewById(R.id.boton2 );
        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*Se está llamando a un intent explícito, es decir, a otra ventana.
                Los parámetros son el contenido de la vista y la clase que abre
                */
                Intent intent = new Intent (v.getContext(), Main2Activity.class);
                //Para exportar parametros se usa la función putExtra, con el nombre de la variable que se pasa y el valor
                intent.putExtra("frase", campoNombre.getText().toString());
                //
                startActivityForResult(intent, 0);
            }
        });

    }

    //Esta sería la segunda forma de invocar un evento OnClick, se crea directamente desde el XML
    public void llamada_creada_desde_xml(View view) {
        etiqueta.setText("Tu nombre es: "+campoNombre.getText());
    }


}
